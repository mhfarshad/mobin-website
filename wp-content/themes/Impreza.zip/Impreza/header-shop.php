<?php defined( 'ABSPATH' ) OR die( 'This script cannot be accessed directly.' );

/**
 * The template for displaying shop headers
 *
 * Do not overload this file directly. Instead have a look at framework/templates/header.php: you should find all
 * the needed hooks there.
 */

us_load_template( 'templates/header' );
us_load_template( 'templates/titlebar' );
