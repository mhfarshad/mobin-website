=== MW Font Changer ===
Contributors: Ghaem
Tags: admin, admin font, font, wordpress font, change font, parsi font, fonts, persian, persian fonts, persian font, admin font editor, WP-Parsi Font Editor, site font changer, font changer, site font, theme font, mandegarweb, ghaem omidi, ghaem, mw, mw fonr editor, mw font changer
Requires at least: 4.0
Stable tag: 5.1
Tested up to: 4.8.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

Change your WordPress dashboard and theme font easy and fast :)

== Description ==

Change your WordPress dashboard and theme font easy and fast :)

= List of some features: =
* Easy Usage
* +30 Fonts
* Change WordPress dashboard font
* Change theme font by entering theme ids and classes

= Fonts list =
* B Esfehan
* B Helal
* B Homa
* B Jadid
* B Koodak
* B Bardiya
* B Mahsa
* B Mehr
* B Mitra
* B Nasim
* B Nazanin
* B Sina
* B Titr
* B Yekan
* Dast Nevis
* Droid Arabic Kufi
* Droid Arabic Naskh
* Gandom
* IR Yekan
* IRANSans
* IRANYekan
* IranNastaliq
* Parastoo
* Sahel
* Samim
* Shabnam
* Shekasteh
* Sultan Adan
* Tanha
* Vazir
* XM Yekan
* Arial
* Comic Sans MS
* Tahoma
* Verdana

= Tested on =
* PC Firefox
* PC IE
* PC Chrome

= Support Forum =
http://forum.wp-parsi.com/

== Installation ==

1. Upload 'parsi-font' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Click on the new menu item "MW Font Changer" and see settings of this plugin.
4. Or you can install the plugin in: "Plugins ==> Add ==> enter the name of plugin (MW Font Changer) in search box and press Enter
5. Install plugin, activate it and enjoy of plugin 

== Frequently Asked Questions ==

= Q. How to use this plugin? = 
A. To use this plugin you should only install plugin, select your custom font in settings page and save changes.

== Screenshots ==

1. Dashboard font settings page
2. Theme font settings page

== Changelog ==

= 5.0 =
* Add new fonts
* Change plugin codes
= 4.3.5 =
* Resolve a problem
= 4.3 =
* Fix a bug
* Add "IRAN Sans" font
= 4.2.5 =
* Fix a bug
= 4.2 =
* Add a feature for change theme font
* Add new fonts
= 4.1 =
* Add new fonts
= 4.0 =
* Add new fonts
* Add font pack (.zip) for download
= 3.9.1 =
* Change style of settings page
* Add Feedback form
= 3.0 =
* Solve a problem
= 2.0 =
* Change codes of plugin
= 1.0 =
* Start Plugin